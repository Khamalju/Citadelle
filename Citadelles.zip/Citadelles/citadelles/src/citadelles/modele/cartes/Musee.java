package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Musee extends Merveille {

    // Cartes placées sous le Musée
    private Carte[] cartesSousMusee;

    // Constructeur du Musée
    public Musee(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 4
        super(nom, type, cout);
        this.cartesSousMusee = new Carte[8]; // Vous pouvez ajuster la taille selon vos besoins
    }

    // Méthode pour gérer l'effet de la fin de tour du Musée
    @Override
    public void finDeTour(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de la fin de tour du Musée
        // Par exemple, permet au joueur de placer une carte sous le Musée
        // et de marquer des points supplémentaires à la fin de la partie
        if (proprietaire.nbQuartiersDansCite() > 0) {
            // Sélectionnez une carte de la main du joueur
            Carte carteSelectionnee = proprietaire.choisirCarteDeMain();

            // Placez la carte sous le Musée
            for (int i = 0; i < cartesSousMusee.length; i++) {
                if (cartesSousMusee[i] == null) {
                    cartesSousMusee[i] = carteSelectionnee;
                    break;
                }
            }
        }
    }

    // Méthode pour gérer l'effet de la fin de partie du Musée
    @Override
    public int pointsFinDePartie() {
        // Ajoutez ici la logique spécifique à l'effet de la fin de partie du Musée
        // Par exemple, marquez 1 point supplémentaire par carte sous le Musée
        int pointsSupplementaires = 0;
        for (Carte carte : cartesSousMusee) {
            if (carte != null) {
                pointsSupplementaires++;
            }
        }
        return pointsSupplementaires;
    }
}
