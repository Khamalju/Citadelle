package citadelles.modele.cartes;

import citadelles.modele.personnages.Echevin;
import citadelles.modele.personnages.Joueur;

public class Ecuries extends Quartier {

    // Constructeur des Écuries
    public Ecuries(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 2
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet des Écuries
    public void effetEcuries(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet des Écuries
        // Par exemple, les Écuries pourraient permettre au propriétaire de bâtir d'autres quartiers même s'il a été confisqué par l'Échevin
        if (proprietaire.getPersonnage() instanceof Echevin) {
            ((Echevin) proprietaire.getPersonnage()).setPeutBatirApresConfiscation(true);
            System.out.println("L'effet des Écuries s'applique : le propriétaire peut bâtir un autre quartier après confiscation par l'Échevin.");
        }
    }
}
