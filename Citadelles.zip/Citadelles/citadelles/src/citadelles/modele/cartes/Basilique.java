 package citadelles.modele.cartes;

import citadelles.modele.cartes.Quartier;
import citadelles.modele.cartes.Merveille;
import citadelles.modele.personnages.Joueur;

public class Basilique extends Merveille {
    public Basilique() {
        super("Basilique", TYPE_QUARTIERS[4], 4);
    }

    @Override
    public void effet(Joueur joueur) {
        // Effet de la Basilique : Calcul des points
        // À la fin de la partie, marquez 1 point supplémentaire pour chaque quartier au coût de construction impair.
        for (Quartier quartier : joueur.getCite()) {
            if (quartier != null && quartier.getCoutConstruction() % 2 != 0) {
                joueur.ajouterPoints(1);
            }
        }
    }
}
