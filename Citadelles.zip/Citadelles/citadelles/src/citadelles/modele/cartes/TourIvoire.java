package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class TourIvoire extends Merveille {

    // Constructeur de la Tour d’Ivoire
    public TourIvoire(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de calcul des points de la Tour d’Ivoire
    @Override
    public int effetFinPartie(Joueur proprietaire) {
        // Vérifie si la Tour d’Ivoire est la seule merveille du joueur à la fin de la partie
        if (proprietaire.getPlateau().getMerveillesJoueur(proprietaire).size() == 1) {
            // Marquez 5 points supplémentaires
            return 5;
        } else {
            // Si la Cour des Miracles et la Tour d’Ivoire sont les deux seules merveilles d’une cité
            // et que le joueur décide de considérer la Cour des Miracles comme n’étant plus une merveille,
            // alors il peut bénéficier du bonus de la Tour d’Ivoire
            // Ajoutez ici la logique spécifique à cette condition
            return 0;
        }
    }
}
