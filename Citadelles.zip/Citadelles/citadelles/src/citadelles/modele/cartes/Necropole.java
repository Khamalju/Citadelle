package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Necropole extends Merveille {

    // Constructeur de la Nécropole
    public Necropole(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de construction de la Nécropole
    @Override
    public void construction(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de construction de la Nécropole
        // Par exemple, permet au joueur de détruire un quartier au lieu de payer son coût
        if (proprietaire.nbQuartiersDansCite() > 0) {
            // Sélectionnez un quartier de la cité du joueur
            Quartier quartierADetruire = proprietaire.choisirQuartierDansCite();

            // Détruisez le quartier au lieu de payer son coût de construction
            proprietaire.retirerQuartierDansCite(quartierADetruire.getNom());
        }
    }
}
