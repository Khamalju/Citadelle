package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Bibliotheque extends Merveille {

    // Constructeur de la Bibliothèque
    public Bibliotheque(String nom, int coutConstruction) {
        super(nom, TypeQuartier.MERVEILLE, coutConstruction);
    }

    // Méthode pour gérer l'effet de la Bibliothèque
    public void effetBibliotheque(Joueur joueur) {
        // Vérifier si le joueur choisit de piocher des cartes au début du tour
        // Vous devrez implémenter la logique pour déterminer si le joueur pioche des cartes

        // Si le joueur choisit de piocher des cartes, conservez-les toutes
        if (joueur.choisitDePiocherDesCartes()) {
            // Logique pour piocher et conserver toutes les cartes
            // Vous devrez implémenter la logique de pioche de cartes
            // et les ajouter à la main du joueur
        }
    }
}