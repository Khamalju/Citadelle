package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Parc extends Merveille {

    // Constructeur du Parc
    public Parc(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 6
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de fin de tour du Parc
    @Override
    public void effetFinDeTour(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de fin de tour du Parc
        // Par exemple, si le joueur n'a aucune carte en main, il pioche 2 cartes
        if (proprietaire.getMain().isEmpty()) {
            proprietaire.piocherCartes(2);
        }
    }
}
