package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public abstract class Merveille extends Quartier {

    public Merveille(String nom, TypeQuartier type, int coutConstruction) {
        super(nom, type, coutConstruction);
    }

    // Méthode abstraite pour l'effet spécifique de chaque merveille
    public abstract void effetMerveille(Joueur proprietaire);

    @Override
    public void effetConstruction(Joueur proprietaire) {
        // Appeler l'effet spécifique de la merveille lors de la construction
        effetMerveille(proprietaire);
    }
}
