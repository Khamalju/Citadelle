package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;
import citadelles.modele.personnages.Personnage;

public class Laboratoire extends Merveille {

    // Constructeur du Laboratoire
    public Laboratoire(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet du Laboratoire à la fin du tour
    @Override
    public void effetLaboratoireFinTour(Joueur proprietaire, Personnage personnageActuel) {
        // Ajoutez ici la logique spécifique à l'effet du Laboratoire
        // Par exemple, le joueur peut défausser 1 carte pour recevoir 2 pièces d'or
        // Vous devez définir la logique exacte selon les règles de votre jeu
        // Supposons que le joueur a une méthode défausserCarte() dans sa classe Joueur
        if (proprietaire.defausserCarte()) {
            System.out.println("Le Laboratoire s'active : " + proprietaire.getNom() +
                    " défausse 1 carte pour recevoir 2 pièces d'or à la fin de son tour.");
            proprietaire.ajouterPieces(2); // Ajoute 2 pièces d'or au propriétaire du Laboratoire
        }
    }
}
