package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Tripot extends Merveille {

    // Constructeur du Tripot
    public Tripot(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 6
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de construction du Tripot
    @Override
    public void effetConstruction(Joueur proprietaire) {
        // Vous pouvez payer tout ou partie du coût de construction du Tripot en cartes de votre main,
        // au prix de 1 carte pour 1 pièce d’or.
        int coutRestant = getCout() - proprietaire.nbPieces();
        if (coutRestant > 0) {
            // Demander au joueur de choisir les cartes à utiliser pour le paiement
            // (la logique exacte dépendra de la manière dont vous gérez les cartes en main du joueur).
            // Ici, supposons une méthode "choisirCartesPourPaiement" dans la classe Joueur.
            Carte[] cartesUtilisees = proprietaire.choisirCartesPourPaiement(coutRestant);

            // Calculer le montant effectif payé en or
            int montantPaye = 0;
            for (Carte carte : cartesUtilisees) {
                montantPaye += 1; // Chaque carte utilisée vaut 1 pièce d'or
                proprietaire.retirerCarteDeLaMain(carte); // Supprimer la carte de la main du joueur
            }

            // Ajouter l'or au trésor du joueur
            proprietaire.ajouterPieces(montantPaye);
        }
    }
}
