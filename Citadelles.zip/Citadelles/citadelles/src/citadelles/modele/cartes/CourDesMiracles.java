package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class CourDesMiracles extends Merveille {

    // Constructeur de la Cour des Miracles
    public CourDesMiracles(String nom) {
        // Le coût de construction est mis à 2
        super(nom, TypeQuartier.MERVEILLE, 2);
    }

    // Méthode pour gérer l'effet de la Cour des Miracles
    public int effetCourDesMiracles(Joueur proprietaire) {
        // Vérifier si le propriétaire considère la Cour des Miracles comme un quartier noble, militaire, marchand ou religieux
        // (Vous pouvez ajouter une logique pour demander au joueur)
        boolean considererCommeQuartierClassique = true;  // Remplacez ceci par votre logique réelle

        if (considererCommeQuartierClassique) {
            // Demander au joueur de choisir un type (couleur) pour la Cour des Miracles
            // (Vous pouvez ajouter une logique pour demander au joueur)
            String typeQuartierChoisi = "Noble";  // Remplacez ceci par votre logique réelle

            // Mettre à jour le type de la Cour des Miracles
            setTypeQuartier(TypeQuartier.valueOf(typeQuartierChoisi.toUpperCase()));

            // Calculer le score final pour la Cour des Miracles (par exemple, 2 points pour chaque quartier du type choisi)
            int scoreFinal = 2 * proprietaire.nbQuartiersDuType(getTypeQuartier());

            return scoreFinal;
        }

        return 0;  // Aucun score si la Cour des Miracles est considérée comme une merveille
    }
}
