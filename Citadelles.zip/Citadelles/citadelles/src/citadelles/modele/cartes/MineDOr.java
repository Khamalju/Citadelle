package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class MineDOr extends Merveille {

    // Constructeur de la Mine d'Or
    public MineDOr(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 6
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de la Mine d'Or lors de la réception de pièces d'or en début de tour
    @Override
    public int revenuDebutTour() {
        // Ajoutez ici la logique spécifique à l'effet de la Mine d'Or
        // Par exemple, elle permet de recevoir 1 pièce d'or supplémentaire en début de tour
        return super.revenuDebutTour() + 1;
    }
}
