package citadelles.modele.cartes;

import citadelles.modele.personnages.Echevin;
import citadelles.modele.personnages.Joueur;

public class Chantier extends Merveille {

    // Constructeur du Chantier
    public Chantier(String nom) {
        // Le coût de construction est mis à 3
        super(nom, TypeQuartier.MERVEILLE, 3);
    }

    // Méthode pour gérer l'effet du Chantier
    public void effetChantier(Joueur proprietaire, Quartier quartierAConstruire) {
        // Vérifier si le propriétaire a le Chantier dans sa cité
        if (proprietaire.quartierPresentDansCite(getNom())) {
            // Demander au joueur s'il souhaite détruire le Chantier pour construire un quartier
            // (Vous pouvez ajouter une logique pour demander à l'utilisateur)
            boolean detruireChantier = true;  // Remplacez ceci par votre logique réelle

            if (detruireChantier) {
                // Retirer le Chantier de la cité
                proprietaire.retirerQuartierDansCite(getNom());

                // Construire le quartier sans payer son coût de construction
                proprietaire.ajouterQuartierDansCite(quartierAConstruire, proprietaire.getPersonnage().getIndice());
            }
        }
    }
}
