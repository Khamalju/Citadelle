package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class EcoleDeMagie extends Merveille {

    // Constructeur de l'École de Magie
    public EcoleDeMagie(String nom) {
        // Le coût de construction est mis à 6
        super(nom, TypeQuartier.MERVEILLE, 6);
    }

    // Méthode pour gérer l'effet de l'École de Magie
    public void effetEcoleDeMagie(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de l'École de Magie
        // Par exemple, l'École de Magie pourrait permettre au propriétaire de percevoir des revenus d'or
        proprietaire.ajouterRevenuOr(1); // Ajout de 1 pièce d'or au revenu du joueur
        System.out.println("L'effet de l'École de Magie s'applique : le propriétaire reçoit 1 pièce d'or de revenu.");
    }
}
