package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public abstract class Quartier {

    private String nom;
    private TypeQuartier type;
    private int coutConstruction;

    public Quartier(String nom, TypeQuartier type, int coutConstruction) {
        this.nom = nom;
        this.type = type;
        this.coutConstruction = coutConstruction;
    }

    public String getNom() {
        return nom;
    }

    public TypeQuartier getType() {
        return type;
    }

    public int getCoutConstruction() {
        return coutConstruction;
    }

    // Méthode abstraite pour l'effet de construction spécifique à chaque quartier
    public abstract void effetConstruction(Joueur proprietaire);

    // Autres méthodes communes à tous les quartiers, si nécessaire
}
