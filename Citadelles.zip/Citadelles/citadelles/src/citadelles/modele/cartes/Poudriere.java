package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Poudriere extends Merveille {

    // Constructeur de la Poudrière
    public Poudriere(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 3
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de fin de tour de la Poudrière
    @Override
    public void effetFinDeTour(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de fin de tour de la Poudrière
        // Par exemple, le joueur peut détruire simultanément la Poudrière et un autre quartier de son choix
        // Vous devez mettre en place une logique pour permettre au joueur de détruire un autre quartier
    }
}
