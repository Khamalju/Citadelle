package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;
import citadelles.modele.personnages.Personnage;

public class GrandeMuraille extends Merveille {

    // Constructeur de la Grande Muraille
    public GrandeMuraille(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 6
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de la Grande Muraille
    @Override
    public void effetGrandeMuraille(Joueur proprietaire, Personnage personnageAffecte) {
        // Ajoutez ici la logique spécifique à l'effet de la Grande Muraille
        // Par exemple, la Grande Muraille pourrait imposer un coût supplémentaire pour affecter un quartier
        if (personnageAffecte != null && personnageAffecte.getRang() == 8) {
            System.out.println("La Grande Muraille s'active : " + personnageAffecte.getNom() +
                    " doit payer 1 pièce d'or supplémentaire pour affecter un quartier de la cité de " +
                    proprietaire.getNom() + ".");
            personnageAffecte.retirerPieces(1); // Retire 1 pièce d'or supplémentaire au personnage de rang 8
        }
    }
}
