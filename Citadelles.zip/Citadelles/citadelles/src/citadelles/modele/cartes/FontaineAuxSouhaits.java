package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class FontaineAuxSouhaits extends Merveille {

    // Constructeur de la Fontaine aux Souhaits
    public FontaineAuxSouhaits(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de la Fontaine aux Souhaits
    @Override
    public void effetFontaineAuxSouhaits(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de la Fontaine aux Souhaits
        // Par exemple, la Fontaine aux Souhaits pourrait donner des points supplémentaires pour chaque merveille dans la cité
        int pointsSupplementaires = proprietaire.getPersonnage().getPlateau().compterMerveilles(proprietaire);
        proprietaire.ajouterPoints(pointsSupplementaires);
        System.out.println("L'effet de la Fontaine aux Souhaits s'applique : le propriétaire marque " + pointsSupplementaires + " points supplémentaires.");
    }
}
