package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Observatoire extends Merveille {

    // Constructeur de l'Observatoire
    public Observatoire(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 4
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de revenu (cartes quartier) de l'Observatoire
    @Override
    public void effetRevenu(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de revenu de l'Observatoire
        // Par exemple, permet au joueur de choisir parmi 3 cartes au lieu de 2 lorsqu'il pioche des cartes
        int nombreDeCartesAChoisir = 3;
        proprietaire.piocherCartes(nombreDeCartesAChoisir);
    }
}
