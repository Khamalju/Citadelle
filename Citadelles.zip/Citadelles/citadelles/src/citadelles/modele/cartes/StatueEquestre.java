package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class StatueEquestre extends Merveille {

    // Constructeur de la Statue Équestre
    public StatueEquestre(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 3
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de fin de partie de la Statue Équestre
    @Override
    public int effetFinDePartie(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de fin de partie de la Statue Équestre
        // Par exemple, si le joueur détient la couronne, il marque 5 points supplémentaires
        if (proprietaire.getPossedeCouronne()) {
            return 5;
        } else {
            return 0;
        }
    }
}
