package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Forge extends Merveille {

    // Constructeur de la Forge
    public Forge(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de la Forge
    @Override
    public void effetForge(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de la Forge
        // Par exemple, la Forge pourrait permettre au propriétaire de piocher 3 cartes en payant 2 pièces d'or
        if (proprietaire.nbPieces() >= 2) {
            proprietaire.retirerPieces(2); // Retire 2 pièces d'or
            for (int i = 0; i < 3; i++) {
                proprietaire.getPersonnage().getPlateau().getPioche().piocherCarte(proprietaire);
            }
            System.out.println("L'effet de la Forge s'applique : le propriétaire pioche 3 cartes en échange de 2 pièces d'or.");
        } else {
            System.out.println("Le propriétaire n'a pas assez de pièces d'or pour activer l'effet de la Forge.");
        }
    }
}
