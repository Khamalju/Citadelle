package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;
import citadelles.modele.personnages.Personnage;

public class Hospice extends Merveille {

    // Constructeur de l'Hospice
    public Hospice(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 4
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de l'Hospice à la fin du tour
    @Override
    public void effetHospiceFinTour(Joueur proprietaire, Personnage personnageActuel) {
        // Ajoutez ici la logique spécifique à l'effet de l'Hospice
        // Par exemple, si le propriétaire n'a aucune pièce d'or à la fin de son tour, il gagne 1 pièce d'or
        if (proprietaire.nbPieces() == 0) {
            System.out.println("L'Hospice s'active : " + proprietaire.getNom() +
                    " gagne 1 pièce d'or à la fin de son tour.");
            proprietaire.ajouterPieces(1); // Ajoute 1 pièce d'or au propriétaire de l'Hospice
        }
    }
}
