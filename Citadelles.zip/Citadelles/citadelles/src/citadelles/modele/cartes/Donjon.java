package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Donjon extends Merveille {

    // Constructeur du Donjon
    public Donjon(String nom) {
        // Le coût de construction est mis à 3
        super(nom, TypeQuartier.MERVEILLE, 3);
    }

    // Méthode pour gérer l'effet du Donjon
    public void effetDonjon(Joueur proprietaire) {
        // Vérifier si le Donjon est affecté par les pouvoirs des personnages de rang 8
        if (!proprietaire.getPersonnage().getNom().equals("Roi") && !proprietaire.getPersonnage().getNom().equals("Condottiere")) {
            // L'effet du Donjon s'applique si le personnage du propriétaire n'est pas le Roi ni le Condottiere
            // Ajoutez ici la logique spécifique à l'effet du Donjon
            // Par exemple, le Donjon pourrait protéger le propriétaire contre certains pouvoirs des personnages de rang 8
            System.out.println("L'effet du Donjon s'applique : le propriétaire est protégé contre les pouvoirs des personnages de rang 8.");
        } else {
            System.out.println("Le Donjon n'est pas affecté par les pouvoirs des personnages de rang 8.");
        }
    }
}
