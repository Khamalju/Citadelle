package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;
import citadelles.modele.personnages.Personnage;

public class Theatre extends Merveille {

    // Constructeur du Théâtre
    public Theatre(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 6
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de sélection du Théâtre
    @Override
    public void effetSelection(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de sélection du Théâtre
        // Par exemple, permettre au propriétaire du Théâtre d'échanger sa carte Personnage
        // avec celle d'un autre joueur sans voir les cartes des autres joueurs

        // Vérifiez si la partie se joue à 2 ou 3 joueurs
        if (proprietaire.getPlateau().getNombreJoueurs() > 3) {
            // Le propriétaire du Théâtre choisit avec qui il fait l'échange
            Joueur autreJoueur = /* logique de sélection du joueur */;
            // Échange des cartes Personnage entre le propriétaire et l'autre joueur
            Personnage carteProprietaire = proprietaire.getPersonnage();
            proprietaire.setPersonnage(autreJoueur.getPersonnage());
            autreJoueur.setPersonnage(carteProprietaire);
        } else {
            // Le propriétaire du Théâtre choisit la carte Personnage parmi les deux cartes
            // du joueur choisi pour l'échange, sans les regarder
            Joueur autreJoueur = /* logique de sélection du joueur */;
            Personnage carteProprietaire = proprietaire.getPersonnage();
            Personnage carteAutreJoueur = autreJoueur.getPersonnage();

            // Échange des cartes Personnage entre le propriétaire et l'autre joueur
            proprietaire.setPersonnage(carteAutreJoueur);
            autreJoueur.setPersonnage(carteProprietaire);
        }
    }
}
