package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Capitole extends Merveille {

    // Indique si l'effet du Capitole a déjà été utilisé
    private boolean effetUtilise;

    // Constructeur du Capitole
    public Capitole(String nom, int coutConstruction) {
        super(nom, TypeQuartier.MERVEILLE, coutConstruction);
        this.effetUtilise = false;
    }

    // Méthode pour gérer l'effet du Capitole à la fin de la partie
    public void effetCapitole(Joueur joueur) {
        // Vérifier si l'effet du Capitole n'a pas déjà été utilisé
        if (!effetUtilise) {
            // Vérifier si le joueur a au moins 3 quartiers du même type dans sa cité
            if (joueur.aAuMoinsTroisQuartiersDuMemeType()) {
                // Marquer 3 points supplémentaires à la fin de la partie
                joueur.ajouterPoints(3);

                // Mettre à jour l'indicateur d'utilisation de l'effet
                effetUtilise = true;
            }
        }
    }
}
