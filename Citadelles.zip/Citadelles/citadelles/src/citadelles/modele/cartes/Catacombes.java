package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Catacombes extends Merveille {

    // Constructeur des Catacombes
    public Catacombes(String nom) {
        // Le coût de construction est mis à 0, car les Catacombes ne peuvent pas être construites
        super(nom, TypeQuartier.MERVEILLE, 0);
    }

    // Méthode pour gérer l'effet des Catacombes
    public void effetCatacombes(Joueur proprietaire) {
        // Vérifier si le propriétaire a les Catacombes dans sa main
        if (proprietaire.quartierPresentDansMain(getNom())) {
            // Ajouter 3 points supplémentaires à la fin de la partie
            proprietaire.ajouterPoints(3);
        }
    }
}
