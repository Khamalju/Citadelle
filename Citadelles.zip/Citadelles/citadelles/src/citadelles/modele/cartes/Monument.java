package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Monument extends Merveille {

    // Constructeur du Monument
    public Monument(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 4
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de la construction du Monument
    @Override
    public void construire(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de la construction du Monument
        // Par exemple, elle empêche la construction si le joueur a déjà 5 quartiers
        if (proprietaire.nbQuartiersDansCite() < 5) {
            proprietaire.ajouterQuartierDansCite(this);
            proprietaire.nbQuartiers++; // Compte comme 2 quartiers
        }
    }
}
