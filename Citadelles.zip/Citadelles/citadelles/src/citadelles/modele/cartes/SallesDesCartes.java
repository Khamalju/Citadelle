package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class SallesDesCartes extends Merveille {

    // Constructeur de la Salles des Cartes
    public SallesDesCartes(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de fin de partie de la Salles des Cartes
    @Override
    public int effetFinDePartie(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet de fin de partie de la Salles des Cartes
        // Par exemple, le joueur marque 1 point supplémentaire par carte dans sa main
        int pointsSupplementaires = proprietaire.getMain().size();
        return pointsSupplementaires;
    }
}
