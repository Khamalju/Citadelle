package citadelles.modele.cartes;

import citadelles.modele.personnages.Echevin;
import citadelles.modele.personnages.Diplomate;
import citadelles.modele.personnages.Capitaine;
import citadelles.modele.personnages.Joueur;
import citadelles.modele.personnages.Personnage;

public class Carriere extends Merveille {

    // Constructeur de la Carrière
    public Carriere(String nom, int coutConstruction) {
        super(nom, TypeQuartier.MERVEILLE, coutConstruction);
    }

    // Méthode pour gérer l'effet de la Carrière
    public void effetCarriere(Joueur proprietaire, Quartier quartier) {
        // Vérifier si le propriétaire est autorisé à construire des quartiers identiques
        if (peutConstruireDesQuartiersIdentiques(proprietaire)) {
            // Construire le quartier identique
            proprietaire.ajouterQuartierDansCite(quartier);
        }
    }

    // Méthode pour vérifier si le propriétaire peut construire des quartiers identiques
    private boolean peutConstruireDesQuartiersIdentiques(Joueur proprietaire) {
        // Vérifier si le propriétaire n'est pas l'Échevin, le Diplomate ou le Capitaine
        Personnage personnage = proprietaire.getPersonnage();
        return !(personnage instanceof Echevin || personnage instanceof Diplomate || personnage instanceof Capitaine);
    }
}
