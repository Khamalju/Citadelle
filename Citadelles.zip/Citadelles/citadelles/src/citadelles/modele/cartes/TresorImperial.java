package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class TresorImperial extends Merveille {

    // Constructeur du Trésor Impérial
    public TresorImperial(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de calcul des points du Trésor Impérial
    @Override
    public int effetFinPartie(Joueur proprietaire) {
        // Marquez 1 point supplémentaire par pièce d’or dans le trésor du joueur à la fin de la partie
        return proprietaire.nbPieces();
    }
}
