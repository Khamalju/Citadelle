package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Manufacture extends Merveille {

    // Constructeur de la Manufacture
    public Manufacture(String nom, TypeQuartier type, int cout) {
        // Le coût de construction est mis à 5
        super(nom, type, cout);
    }

    // Méthode pour gérer l'effet de la Manufacture lors de la construction d'une autre merveille
    @Override
    public int coutConstructionAutreMerveille() {
        // Ajoutez ici la logique spécifique à l'effet de la Manufacture
        // Par exemple, elle permet de payer 1 pièce d'or de moins lors de la construction d'une autre merveille
        return super.coutConstructionAutreMerveille() - 1;
    }
}
