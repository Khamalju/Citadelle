package citadelles.modele.cartes;

import citadelles.modele.personnages.Joueur;

public class Dracoport extends Merveille {

    // Constructeur du Dracoport
    public Dracoport(String nom) {
        // Le coût de construction est mis à 6
        super(nom, TypeQuartier.MERVEILLE, 6);
    }

    // Méthode pour gérer l'effet du Dracoport
    public void effetDracoport(Joueur proprietaire) {
        // Ajoutez ici la logique spécifique à l'effet du Dracoport
        // Par exemple, le Dracoport pourrait ajouter 2 points supplémentaires à la fin de la partie
        proprietaire.ajouterPoints(2);
        System.out.println("L'effet du Dracoport s'applique : le propriétaire marque 2 points supplémentaires à la fin de la partie.");
    }
}
