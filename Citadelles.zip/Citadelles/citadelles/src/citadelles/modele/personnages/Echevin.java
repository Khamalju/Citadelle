package citadelles.modele.personnages;

import citadelles.modele.Caracteristiques;
import citadelles.modele.Personnage;
import controleur.Interaction;

public class Echevin extends Personnage {

    public Echevin() {
        super("Échevin", 1, Caracteristiques.ECHEVIN);
    }

    @Override
    public void utiliserPouvoir() {
        // Supposons que l'Échevin peut choisir de construire un quartier gratuitement
        System.out.println("En tant qu'Échevin, vous pouvez construire un quartier gratuitement.");
        // Logique pour construire un quartier sans payer
    }

    @Override
    public void percevoirRessourcesSpecifiques() {
        // Logique spécifique à l'Échevin pour percevoir des ressources
    }
}