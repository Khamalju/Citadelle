package citadelles.modele.personnages;

import citadelles.modele.Joueur;
import citadelles.modele.Plateau;
import citadelles.modele.Quartier;
import citadelles.modele.cartes.Merveille;

public class Personnage {
    private String nom;
    private Plateau plateau;

    // Constructeur
    public Personnage(String nom, Plateau plateau) {
        this.nom = nom;
        this.plateau = plateau;
    }

    // Accesseur nom
    public String getNom() {
        return nom;
    }

    // Accesseur plateau
    public Plateau getPlateau() {
        return plateau;
    }

    // Méthode pour appliquer le pouvoir du personnage
    public void appliquerPouvoir() {
        // Implémentez le pouvoir du personnage ici
        // Exemple : this.plateau.getJoueurActif().ajouterPieces(2);
    }

    // Méthode pour choisir une merveille
    public void choisirMerveille(Joueur joueur, Merveille merveille) {
        joueur.ajouterMerveille(merveille);
        // Vous pouvez ajouter des traitements supplémentaires ici
    }

    // Méthode pour choisir un quartier dans la cité
    public void choisirQuartier(Joueur joueur, Quartier quartier) {
        joueur.ajouterQuartierDansCite(quartier);
        // Vous pouvez ajouter des traitements supplémentaires ici
    }
}
