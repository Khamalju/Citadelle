package citadelles.modele.personnages;

import citadelles.modele.Caracteristiques;
import citadelles.modele.Personnage;
import controleur.Interaction;

public class Sorciere extends Personnage {

    public Sorciere() {
        super("Sorcière", 1, Caracteristiques.SORCIERE);
    }

    @Override
    public void utiliserPouvoir() {
        // Supposons que la Sorcière peut échanger sa main de cartes avec un autre joueur
        System.out.println("En tant que Sorcière, vous pouvez échanger vos cartes avec un autre joueur.");
        // Logique pour échanger les cartes
    }

    @Override
    public void percevoirRessourcesSpecifiques() {
        // Logique spécifique à la Sorcière pour percevoir des ressources
    }
}